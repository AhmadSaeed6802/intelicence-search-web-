﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Web_API.BusinessLayer;
using Web_API.Models;

namespace Web_API.Controllers
{
    public class StudentsController : ApiController
    {
        public BL dataLayer = new BL();

        [HttpGet]
        [Route("GetListOfUsers")]
        public List<Students> GetListOfBootcampUsers()
        {
            try
            {
                List<Students> users = new List<Students>();
                users = dataLayer.GetListOfUsers();
                return users;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetListOfStudents due to "
                   + exception.Message, exception.InnerException);
            }
        }

        





    }
}
