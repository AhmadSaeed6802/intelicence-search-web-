﻿namespace Web_API.Models
{
    public class Students
    {
        
        public int UserID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Age { get; set; }
        public string Course { get; set; }

    }

    


}