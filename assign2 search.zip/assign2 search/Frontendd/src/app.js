﻿$(document).ready(() => {
    var students;
    const POSTS_API = "http://localhost:3013/GetListOfUsers";

    // fetch and display posts for the first time

    fetchstudents();

    // updateStats();

    // function to render students available in the array students[]

    function displaystudents() {
        $(".posts-container").empty();

        for (let i = 0; i < students.length; i++) {
            $(".posts-container").append(makePost(students[i]));
        }
    }

    // function to make a post

    function makePost(student) {
        return `

                <div class="post">
                    <p>First Name</p>
                    <p>${student.FirstName}</p>

                    <p>Last Name</p>
                    <p>${student.LastName}</p>

                    <p>Age</p>
                    <p>${student.Age}</p>

                    <p>Course </p>
                    <p>${student.Course}</p>

                </div>

                `;
    }

    function displayError(error) {
        $(".posts-container").html(
            '<div class="error">Some Error has occured!</div>'
        );
    }

    function fetchstudents() {
        $.ajax({
            method: "GET",

            url: POSTS_API,

            success: (data) => {
                students = data;

                displaystudents();
            },

            error: displayError,
        });
    }




    $('#search').on('input', function () {
        var searchField = $('#search').val();
        if (searchField !== '') {
            $.ajax({
                url: 'http://localhost:3013/GetListOfUsers', // your API endpoint
                type: 'GET',
                data: { s: searchField },
                success: function (response) {
                    var suggestions = '';
                    $.each(response, function (key, value) {
                        if (value.FirstName.toLowerCase().includes(searchField.toLowerCase()) ||
                            value.LastName.toLowerCase().includes(searchField.toLowerCase())) {
                            suggestions += '<p>' + value.FirstName + ' ' + value.LastName + '</p>';
                        }
                    });
                    $('#suggestions').html(suggestions);
                },
                error: function (err) {
                    console.log(err);
                }
            });
        } else {
            $('#suggestions').html('');
        }
    });

});


