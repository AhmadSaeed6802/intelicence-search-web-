﻿using System;
using System.Collections.Generic;
using System.Data;
using Web_API.Data_Layer;
using Web_API.Models;

namespace Web_API.BusinessLayer
{
    public class BL
    {

        public DataLayer dataLayer = new DataLayer();
        public List<Students> GetListOfUsers()
        {
            try
            {
                DataTable table = new DataTable();
                List<Students> listUsers = new List<Students>();
                table = dataLayer.GetListOfUsers();

                if (table != null && table.Rows.Count > 0)
                {
                    foreach (DataRow dataRow in table.Rows)
                    {
                        Students user = new Students();
                        //user.UserID = Convert.ToInt32(dataRow["UserID"]);
                        user.FirstName = dataRow["FirstName"].ToString();
                        user.LastName = dataRow["Lastname"].ToString();
                        user.Age = dataRow["Age"].ToString();
                        user.Course = dataRow["Course"].ToString();
                        listUsers.Add(user);
                    }
                }
                return listUsers;
            }
            catch (Exception exception)
            {
                throw new Exception("An exception of type " + exception.GetType().ToString()
                   + " is encountered in GetListOfStudents due to "
                   + exception.Message, exception.InnerException);
            }
        }


    }
}