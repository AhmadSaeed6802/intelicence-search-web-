CREATE TABLE Students (
UserID int PRIMARY KEY IDENTITY(1,1) NOT NULL,
FirstName varchar(30) NOT NULL,
LastName varchar(30) NOT NULL,
Age varchar(30) NOT NULL,
Course varchar(30) NOT NULL
)

INSERT INTO Students (FirstName, LastName, Age, Course)
VALUES
('Johndoe', 'Michael', '20', 'English'),
('abc', 'def', '22', 'Maths'),
('cde', 'fgh', '21', 'Prgramming')

INSERT INTO Students (FirstName, LastName, Age, Course)
VALUES
('Ali', 'Abdullah', '20', 'English'),
('Mishaal', 'Ifat', '22', 'Maths'),
('Abiha', 'Nawaz', '21', 'Prgramming'),
('Alia', 'Salman', '20', 'English'),
('Faryal', 'Khan', '22', 'Maths'),
('Aneeza', 'Rana', '21', 'Prgramming')

CREATE PROCEDURE GetListOfUsers
AS
BEGIN
    SELECT FirstName, LastName, Age, Course FROM Students;
END

SELECT * FROM Students

